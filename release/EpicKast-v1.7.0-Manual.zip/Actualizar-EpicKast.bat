﻿@echo off
chcp 65001 >nul
echo ===================================================
echo     ACTUALIZADOR MANUAL DE EPICKAST v1.7.0
echo ===================================================
echo.
echo Cerrando EpicKast si esta abierto...
taskkill /F /IM EpicKast.exe >nul 2>&1
timeout /t 1 /nobreak >nul

set "DEST=%LOCALAPPDATA%\Programs\epickast\resources\app.asar"
if not exist "%LOCALAPPDATA%\Programs\epickast\resources" (
    echo [ERROR] No se encontro la carpeta de instalacion de EpicKast en %LOCALAPPDATA%\Programs\epickast.
    pause
    exit /b 1
)

echo Copiando app.asar actualizado a version 1.7.0...
copy /Y "%~dp0app.asar" "%DEST%" >nul
if errorlevel 1 (
    echo [ERROR] No se pudo copiar el archivo.
    pause
    exit /b 1
)

echo.
echo ===================================================
echo   ¡EpicKast actualizado con exito a v1.7.0!
echo ===================================================
echo.
echo Iniciando EpicKast...
start "" "%LOCALAPPDATA%\Programs\epickast\EpicKast.exe"
