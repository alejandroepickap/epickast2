﻿@echo off
chcp 65001 >nul
title Actualizador EpicKast v1.7.2
echo ===================================================
echo     ACTUALIZADOR MANUAL DE EPICKAST v1.7.2
echo ===================================================
echo.
echo Cerrando EpicKast si está abierto...
taskkill /F /IM EpicKast.exe >nul 2>&1
timeout /t 1 /nobreak >nul

set "DEST=%LOCALAPPDATA%\Programs\epickast\resources\app.asar"
if not exist "%LOCALAPPDATA%\Programs\epickast\resources" (
    echo [ERROR] No se encontro la carpeta de instalacion de EpicKast en %LOCALAPPDATA%\Programs\epickast.
    pause
    exit /b 1
)

echo Copiando paquete de aplicacion v1.7.2...
copy /Y "%~dp0app.asar" "%DEST%" >nul
if errorlevel 1 (
    echo [ERROR] No se pudo copiar el archivo app.asar.
    pause
    exit /b 1
)

echo.
echo ===================================================
echo   ¡EpicKast se ha actualizado con éxito a v1.7.2!
echo ===================================================
echo.
echo Iniciando EpicKast actualizado...
start "" "%LOCALAPPDATA%\Programs\epickast\EpicKast.exe"
