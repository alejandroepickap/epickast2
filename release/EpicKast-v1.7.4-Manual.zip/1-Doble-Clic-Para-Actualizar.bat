@echo off
chcp 65001 >nul
title Actualizando EpicKast a v1.7.4
echo Cerrando EpicKast...
taskkill /f /im "EpicKast.exe" >nul 2>&1
timeout /t 1 /nobreak >nul
copy /y "%~dp0app.asar" "%LOCALAPPDATA%\Programs\epickast\resources\app.asar" >nul
echo ¡Listo! Iniciando EpicKast v1.7.4...
start "" "%LOCALAPPDATA%\Programs\epickast\EpicKast.exe"
exit
