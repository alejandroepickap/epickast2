@echo off
chcp 65001 >nul
title Actualizando EpicKast a v1.7.4
echo.
echo =======================================================
echo    Actualizador Oficial de EpicKast v1.7.4
echo =======================================================
echo.
echo Cerrando EpicKast si está en ejecución...
taskkill /f /im "EpicKast.exe" >nul 2>&1
timeout /t 1 /nobreak >nul

set "DEST=%LOCALAPPDATA%\Programs\epickast\resources"
if not exist "%DEST%" (
    echo Error: No se encontro la carpeta de instalacion de EpicKast.
    pause
    exit /b 1
)

echo Copiando archivos de actualizacion...
copy /y "%~dp0app.asar" "%DEST%\app.asar" >nul

echo.
echo ¡Actualización v1.7.4 completada con éxito!
echo Iniciando EpicKast...
start "" "%LOCALAPPDATA%\Programs\epickast\EpicKast.exe"
exit
